#!/bin/sh
# wait-for-network.sh - block until the network is usable (default: up to 60 s).
#
# Used by audio-ready.service. setup.sh installs it as ~/.local/bin/voice-wait-network.
# NetworkManager systems: uses nm-online. Everything else: waits for a default route.
# Exit status 0 = network is up, non-zero = gave up waiting.

timeout_s="${1:-60}"

if command -v nm-online >/dev/null 2>&1 && systemctl is-active --quiet NetworkManager 2>/dev/null; then
    exec nm-online -q -t "$timeout_s"
fi

waited=0
while [ "$waited" -lt "$timeout_s" ]; do
    if ip route show default 2>/dev/null | grep -q .; then
        exit 0
    fi
    sleep 1
    waited=$((waited + 1))
done

echo "voice-wait-network: no default route after ${timeout_s}s" >&2
exit 1
