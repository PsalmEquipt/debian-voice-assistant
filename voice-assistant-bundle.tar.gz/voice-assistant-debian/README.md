# voice-assistant-debian

Turn a Debian box with a USB microphone into a **network microphone server**:

```
USB mic ──► PipeWire ──► RNNoise noise suppression ──► RTP stream (UDP) ──► your PC
```

It starts by itself at boot (no login needed). Optionally it also runs a Home
Assistant voice satellite ([linux-voice-assistant]) on the same cleaned-up mic.

**Status:** built from a working Debian 13 "trixie" machine (PipeWire 1.4.2,
WirePlumber 0.5.8, USB headset mic). The generated configs were compared against
that working setup, PipeWire's own config parser accepts them, and the installer
was exercised in a sandboxed home directory with stubbed `sudo`/`systemctl`
(fresh install, re-run, config change, bad input, checksum failure). It has **not**
yet been run end-to-end on a freshly installed machine - please report how it goes.

## Quick start

```bash
tar -xzf voice-assistant-bundle.tar.gz
cd voice-assistant-debian

./setup.sh --list-devices                      # shows your mic's names (PipeWire must be running)
./setup.sh --dry-run --dest-ip 192.168.1.50    # preview: prints a diff, changes nothing
./setup.sh --dest-ip 192.168.1.50              # do it
```

Run it as your **normal user, not root** - the audio services are per-user. `sudo`
is used only for `apt` and for enabling systemd "linger"; it asks for your password
if it needs it. `--dry-run` needs `envsubst`; on a very minimal system run
`sudo apt-get install gettext-base` first.

Replace `192.168.1.50` with the PC that should receive the audio. Leave
`--dest-ip` out to use multicast (`224.0.0.56`), which any listener on the LAN can join.

## What it does

1. **Packages** - installs only what is missing: `pipewire`, `pipewire-pulse`,
   `pipewire-alsa`, `wireplumber`, `libspa-0.2-modules`, `pulseaudio-utils`,
   `alsa-utils`, `iproute2`, `gettext-base`, `curl`, `unzip` (and friends).
   Nothing is upgraded unless you pass `--upgrade`.
2. **Dependency check** - confirms the tools and the PipeWire RTP and filter-chain
   modules are present, and warns if classic PulseAudio is running.
3. **RNNoise plugin** - there is no Debian package, so it downloads upstream
   release v1.10 of [noise-suppression-for-voice], **verifies its SHA-256**, and keeps
   just `librnnoise_ladspa.so` (x86_64 only). Skipped if you already have it.
4. **Config files** - renders the templates in `config/` and `systemd/` into your
   home directory (table below). Changed files are backed up as
   `FILE.bak-YYYYMMDD-HHMMSS`; identical files are left alone.
5. **Services** - reloads systemd, enables PipeWire, WirePlumber and
   `audio-ready.service`, enables *linger* so it all starts at boot, and restarts
   PipeWire only if something actually changed.
6. **Verifies** the `rtp-mic-send` stream and the denoised mic exist.

Safe to re-run any time.

## Options

| Option | Meaning |
|---|---|
| `--dest-ip IP` / `--dest-port PORT` | Where to send the audio (default `224.0.0.56:5004`) |
| `--session-name NAME` | RTP session name (default: hostname) |
| `--mic-source NAME` | Capture source to stream (default: system default) |
| `--mic-card NAME` | Pin a sound card to a profile that has a mic input (see Troubleshooting) |
| `--no-rnnoise` | Skip noise suppression |
| `--with-lva` | Also run the voice satellite (must already be installed) |
| `--lva-name NAME`, `--wake-model NAME` | Satellite name and wake word |
| `--no-alsa` | Don't install `~/.asoundrc` |
| `--skip-apt` | Don't touch packages |
| `--upgrade` | Also run `apt-get upgrade` |
| `--dry-run` | Show what would change, change nothing |
| `--list-devices` | Print capture sources and sound cards, then exit |

Every default lives in `config/voice-assistant.env` (plain bash assignments, with
comments). Flags override that file. Extra satellite flags, such as a speaker
device, go in `LVA_EXTRA_ARGS`.

## Where things go

| In this project | Installed as |
|---|---|
| `config/pipewire/pipewire.conf.d/50-rtp-mic-send.conf.in` | `~/.config/pipewire/pipewire.conf.d/50-rtp-mic-send.conf` |
| `config/pipewire/pipewire.conf.d/99-input-denoising.conf.in` | `~/.config/pipewire/pipewire.conf.d/99-input-denoising.conf` |
| `config/environment.d/ladspa.conf.in` | `~/.config/environment.d/ladspa.conf` (so PipeWire finds the plugin) |
| `config/wireplumber/wireplumber.conf.d/50-usb-mic-profile.conf.in` | `~/.config/wireplumber/wireplumber.conf.d/` - only with `--mic-card` |
| `config/alsa/asoundrc` | `~/.asoundrc` - skipped if you already have one of your own |
| `systemd/audio-ready.service` | `~/.config/systemd/user/audio-ready.service` |
| `systemd/wait-for-network.sh` | `~/.local/bin/voice-wait-network` |
| `systemd/linux-voice-assistant.service.in` | `~/.config/systemd/user/` - only with `--with-lva` |
| *(downloaded)* RNNoise plugin | `~/.ladspa/librnnoise_ladspa.so` |

Files ending in `.in` are templates; `setup.sh` fills in the `${NAME}` placeholders.

**Why `audio-ready.service`?** PipeWire is socket-activated very early at boot,
before the network is up, and the RTP sender needs a routable network. This
one-shot waits for the network (NetworkManager if present, otherwise a default
route) and then restarts PipeWire so the stream binds cleanly.

## Checking it works

```bash
pw-dump | grep -E '"node.name": "(rtp-mic-send|mic_cleaned)"'   # both lines should appear
systemctl --user status audio-ready.service
wpctl status                                                    # mic_cleaned under Sources
```

The real test is a reboot: wait a minute afterwards and run the first command again.

## Receiving the stream

The stream is **RTP, L16 (16-bit big-endian PCM), 48 kHz, mono**, over UDP, to the
address and port you chose. Any receiver that can play an RTP L16 stream will do;
on another PipeWire machine, see `man libpipewire-module-rtp-source`. Sender
details: `man libpipewire-module-rtp-sink`.

## Troubleshooting

- **No microphone after a cold boot** (works after replugging): WirePlumber picked
  an output-only profile for the card. Run `./setup.sh --list-devices`, then re-run
  with `--mic-card <card NAME>`.
- **Stream missing after boot**: the network came up late. Check
  `journalctl --user -u audio-ready.service`. It waits up to 60 s.
- **Denoised mic missing**: `journalctl --user -u pipewire | grep -i ladspa`; check
  that `~/.ladspa/librnnoise_ladspa.so` exists and that
  `systemctl --user show-environment | grep LADSPA` shows its folder.
- **PulseAudio warning**: the classic `pulseaudio` daemon fights with `pipewire-pulse`.
  Run `systemctl --user mask --now pulseaudio.service pulseaudio.socket`.
- **Not x86_64**: the prebuilt RNNoise plugin is x86_64 only. Build it from source
  and put `librnnoise_ladspa.so` in `~/.ladspa`, or use `--no-rnnoise`.

## Undo

```bash
systemctl --user disable --now audio-ready.service
rm -f ~/.config/pipewire/pipewire.conf.d/{50-rtp-mic-send,99-input-denoising}.conf \
      ~/.config/wireplumber/wireplumber.conf.d/50-usb-mic-profile.conf \
      ~/.config/systemd/user/audio-ready.service ~/.local/bin/voice-wait-network
systemctl --user daemon-reload
systemctl --user restart pipewire.service
```

If `setup.sh` replaced a file you had before, your original is next to it as `*.bak-*`.

## Rebuilding the bundle

After editing the project folder in your home directory:

```bash
tar -czvf voice-assistant-bundle.tar.gz -C "$HOME" voice-assistant-debian
```

`c` create an archive, `z` compress with gzip, `v` list files as they are added,
`f` name of the output file. `-C "$HOME"` makes the paths inside the archive start
at `voice-assistant-debian/`, so it extracts into a single clean folder.

[linux-voice-assistant]: https://github.com/OHF-Voice/linux-voice-assistant
[noise-suppression-for-voice]: https://github.com/werman/noise-suppression-for-voice
